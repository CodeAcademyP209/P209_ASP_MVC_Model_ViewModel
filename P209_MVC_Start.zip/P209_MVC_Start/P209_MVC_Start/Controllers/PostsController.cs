﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P209_MVC_Start.Controllers
{
    public class PostsController : Controller
    {
        public ActionResult Index(string authorName)
        {
            //string author = authorName ?? "Unknown";
            string author = authorName != null ? authorName : "Unknown";

            return Content($"Siz hazirda Postun Idnex sehifedesiniz. Muellif adi: {author}"); //ternary
        }

        // GET: Posts
        public ActionResult Details(int? id)
        {
            if(id == null)
            {
                return Content("Id gelmeyib");
            }

            return Content($"Sizin gonderdiyiniz id: {id}");
        }
    }
}