﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_MVC_Start.Models;
using P209_MVC_Start.Models.ViewModels;

namespace P209_MVC_Start.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //connect to database and get the fullname
            User user1 = new User()
            {
                Id = 1,
                Lastname = "Dadash-zade",
                Birthdate = new DateTime(1991, 11, 20),
                Email = "samir.d@code.edu.az",
                Image = "img1.jpeg",
                Firstname = "Samir"
            };
            User user2 = new User()
            {
                Id = 2,
                Lastname = "Ezizov",
                Birthdate = new DateTime(1999, 11, 20),
                Email = "bashir@code.edu.az",
                Image = "img2.jpg",
                Firstname = "Beshir"
            };

            Post post = new Post
            {
                Id = 1,
                Title = "It is demo post title",
                Content = "It is demo post content",
                Image = "image_gallery.gif",
                CreatedAt = DateTime.Now.AddDays(3)
            };
            Post post2 = new Post
            {
                Id = 2,
                Title = "It is demo post title 2",
                Content = "It is demo post content 2",
                Image = null,
                CreatedAt = DateTime.Now
            };
            Post post3 = new Post
            {
                Id = 3,
                Title = "It is demo post title 3",
                Content = "It is demo post content 3",
                Image = null,
                CreatedAt = DateTime.Now.AddDays(-3)
            };

            List<Post> posts = new List<Post> { post, post2, post3 };
            List<User> users = new List<User> { user1, user2 };

            HomeIndexVM vm = new HomeIndexVM
            {
                Users = users,
                Posts = posts
            };

            return View(vm);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult demo()
        {
            return View();
        }

        public string GetName(Person student)
        {
            return student.Firstname;
        }
    }

    public class Person
    {
        public string Firstname { get; set; }
    }

    public class Student : Person
    {
        public string UniversityName { get; set; }
    }

    class Teacher : Person
    {
        public string Job { get; set; }
    }
}