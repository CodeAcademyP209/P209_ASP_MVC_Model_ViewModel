﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P209_MVC_Start.Models.ViewModels
{
    public class HomeIndexVM
    {
        public IEnumerable<User> Users { get; set; }
        public IEnumerable<Post> Posts { get; set; }
    }
}